package com.hotelbooking.auth.domain;

public enum Role {
    ADMIN,
    MANAGER,
    RECEPTIONIST,
    GUEST
}