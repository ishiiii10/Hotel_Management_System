package com.hotelbooking.hotel.enums;

public enum City {
    DELHI,
    MUMBAI,
    BANGALORE,
    CHENNAI,
    HYDERABAD,
    KOLKATA,
    PUNE,
    JAIPUR,
    AHMEDABAD,
    PATNA,
    KOCHI
    
    
}