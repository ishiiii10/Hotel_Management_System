package com.hotelbooking.hotel.enums;

public enum RoomCategory {
	STANDARD,
    DELUXE,
    EXECUTIVE,
    SUITE,
    PRESIDENTIAL

}
