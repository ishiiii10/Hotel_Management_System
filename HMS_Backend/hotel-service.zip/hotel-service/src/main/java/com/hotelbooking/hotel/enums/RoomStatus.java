package com.hotelbooking.hotel.enums;

public enum RoomStatus {
    AVAILABLE,
    OCCUPIED,
    MAINTENANCE,
    OUT_OF_SERVICE, 
    INACTIVE,
   
}