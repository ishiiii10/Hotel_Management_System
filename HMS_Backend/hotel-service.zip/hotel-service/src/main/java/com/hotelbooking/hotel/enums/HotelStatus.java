package com.hotelbooking.hotel.enums;

public enum HotelStatus {
    DRAFT,
    ACTIVE,
    INACTIVE,
    BLOCKED
}