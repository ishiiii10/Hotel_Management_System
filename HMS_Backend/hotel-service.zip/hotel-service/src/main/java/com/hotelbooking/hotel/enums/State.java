package com.hotelbooking.hotel.enums;

public enum State {
	
	    DELHI,
	    MAHARASHTRA,
	    KARNATAKA,
	    TAMIL_NADU,
	    TELANGANA,
	    WEST_BENGAL,
	    RAJASTHAN,
	    GUJARAT,
	    BIHAR,
	    KERALA

}
