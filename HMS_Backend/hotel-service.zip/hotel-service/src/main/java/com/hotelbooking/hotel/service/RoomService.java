package com.hotelbooking.hotel.service;


import java.util.List;

import com.hotelbooking.hotel.dto.request.CreateRoomRequest;
import com.hotelbooking.hotel.dto.response.RoomResponse;
import com.hotelbooking.hotel.enums.RoomStatus;
import com.hotelbooking.hotel.domain.Room;

public interface RoomService {

    Long createRoom(CreateRoomRequest request);
    
    RoomResponse getRoomById(Long roomId);
    
    void deleteRoom(Long roomId);

    List<RoomResponse> getRoomsByHotel(Long hotelId);
    
    Long updateRoom(Long roomId, CreateRoomRequest request);

    void updateRoomStatus(Long roomId, RoomStatus status);

    void updateRoomActiveStatus(Long roomId, boolean isActive);
}