package com.hotelbooking.hotel.enums;



public enum Hotel_Category {

    HOTEL,
    VILLA,
    APARTMENT,
    RESORT,
    HOSTEL,
    GUEST_HOUSE,
    HOMESTAY,
    BOUTIQUE,
}